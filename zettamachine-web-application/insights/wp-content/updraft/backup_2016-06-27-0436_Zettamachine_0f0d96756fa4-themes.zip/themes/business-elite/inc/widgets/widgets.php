<?php
/* include widgets */
/* include Advertisement Widget */
	require_once( 'widget-advert.php' );
/* include Advertisement Widget */
	require_once( 'widget-adsens.php' );
/* include Spider Random Post */
	require_once( 'Spider_Random_Post.php' );
/* include Category Post */
	require_once( 'widget-category.php' );
/* include Category Post */
	require_once( 'widget-category-tabs.php' );
/* include percent widget */
	require_once( 'widget-percent.php' );
/* include Category Post */
	require_once( 'widget-events-category.php' );
/* include social icons widget */
	require_once( 'widget-social-icons.php' );
?>