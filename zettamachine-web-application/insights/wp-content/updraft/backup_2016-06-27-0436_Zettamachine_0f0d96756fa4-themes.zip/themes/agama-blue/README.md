## Agama Blue

Agama Blue is child-theme of Agama theme.

## Parent Theme

Agama Blue is a child theme of Agama. You must have it installed to use this theme.
* [Agama](https://www.theme-vision.com/agama/) by ThemeVision Themes.

## Copyright and License

Agama Blue WordPress Theme, Copyright 2015 Jaroslav Svetlik.

Agama Blue is distributed under the terms of the GNU GPL.

## Image Credits

Image used on screenshot:
 * John Cobb - https://unsplash.com/johncobb - https://unsplash.com/photos/ssAcdlJRsI4 - CC0 1.0 License
 
## Changelog

= 1.0.4 - 10 Mar 2016 =
* UPDATED: Few minor changes.

= 1.0.3 - 06 Mar 2016 =
* UPDATED: Default header style for Agama Blue.

= 1.0.2 - 05 Mar 2016 =
* UPDATED: Child theme customize options under "Agama Blue Options" panel.
* FIXED: Various issues.

= 1.0.1 - 14 Dec 2015 =
* ADDED: Frontpage blog feature.