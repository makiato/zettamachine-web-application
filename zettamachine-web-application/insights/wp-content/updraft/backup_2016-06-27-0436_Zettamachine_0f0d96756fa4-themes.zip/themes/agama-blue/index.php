<?php 
/**
 * The main template file
 *
 * @package Theme-Vision
 * @subpackage Agama Blue
 * @since 1.0
 */ ?>

<?php get_header(); ?>

<?php get_sidebar(); ?>

<?php get_footer(); ?>
