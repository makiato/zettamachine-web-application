<?php

if ( ! class_exists( 'Kirki_Settings' ) ) {
	class Kirki_Settings extends Kirki_Customizer {

		public function __construct( $args ) {

			parent::__construct( $args );
			$this->add_settings( $args );

		}

		public function add_settings( $args ) {

			if ( isset( $args['settings'] ) && is_array( $args['settings'] ) ) {
				$settings          = $args['settings'];
				$defaults          = isset( $args['default'] ) ? $args['default'] : array();
				$sanitize_callback = $args['sanitize_callback'];
				foreach ( $settings as $setting_key => $setting_value ) {
					$default    = ( isset( $defaults[ $setting_key ] ) ) ? $defaults[ $setting_key ] : '';
					$transport  = isset( $args['transport'] ) ? $args['transport'] : 'refresh';

					if ( isset( $args['sanitize_callback'] ) && is_array( $args['sanitize_callback'] ) ) {
						if ( isset( $args['sanitize_callback'][ $setting_key ] ) ) {
							$sanitize_callback = Kirki_Field::sanitize_callback( '', array( 'sanitize_callback' => $args['sanitize_callback'][ $setting_key ] ) );
						}
					}
					$this->wp_customize->add_setting( $setting_value, array(
						'default'           => $default,
						'type'              => $args['option_type'],
						'capability'        => $args['capability'],
						'sanitize_callback' => $sanitize_callback,
						'transport'         => $transport,
					) );
				}
			}

			if ( isset( $args['type'] ) && array_key_exists( $args['type'], Kirki_Control::$setting_types ) ) {
				// We must instantiate a custom class for the setting
				$setting_classname = Kirki_Control::$setting_types[ $args['type'] ];
				$this->wp_customize->add_setting( new $setting_classname( $this->wp_customize, $args['settings'], array(
					'default'           => isset( $args['default'] ) ? $args['default'] : '',
					'type'              => $args['option_type'],
					'capability'        => $args['capability'],
					'transport'         => isset( $args['transport'] ) ? $args['transport'] : 'refresh',
					'sanitize_callback' => $args['sanitize_callback'],
				) ) );

			} else {
				$this->wp_customize->add_setting( $args['settings'], array(
					'default'           => isset( $args['default'] ) ? $args['default'] : '',
					'type'              => $args['option_type'],
					'capability'        => $args['capability'],
					'transport'         => isset( $args['transport'] ) ? $args['transport'] : 'refresh',
					'sanitize_callback' => $args['sanitize_callback'],
				) );
			}

		}
	}
}
